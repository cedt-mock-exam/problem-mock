#ifndef __STUDENT_H_
#define __STUDENT_H_
#include "list.h"
template <typename T>
void CP::list<T>::implant(CP::list<T> &other,int pos1,int pos2,int count){
    // Edit here.
}
#endif