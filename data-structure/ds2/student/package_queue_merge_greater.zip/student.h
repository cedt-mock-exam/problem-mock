#ifndef __STUDENT_H_
#define __STUDENT_H_

#include "queue.h"

template <typename T> void CP::queue<T>::merge_greater(CP::queue<T> &other) {
  // implement this from scratch
}

#endif